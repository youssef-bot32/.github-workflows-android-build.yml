import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { getPlantStatus } from "@/lib/esp32";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/settings")({
  head: () => ({
    meta: [
      { title: "Smart Plant | Settings" },
      { name: "description", content: "Manage ESP32 connection and appearance for your Smart Plant." },
    ],
  }),
  component: SettingsPage,
});

type Theme = "light" | "dark";
type ConnState = "checking" | "online" | "offline";

function SettingsPage() {
  const [theme, setTheme] = useState<Theme>("dark");
  const [conn, setConn] = useState<ConnState>("checking");
  const [lastChecked, setLastChecked] = useState<string | null>(null);

  // Initialize theme from localStorage / current document state
  useEffect(() => {
    const stored = (typeof localStorage !== "undefined" && localStorage.getItem("theme")) as Theme | null;
    const initial: Theme = stored ?? (document.documentElement.classList.contains("dark") ? "dark" : "light");
    applyTheme(initial);
    setTheme(initial);
  }, []);

  const applyTheme = (t: Theme) => {
    const root = document.documentElement;
    if (t === "dark") root.classList.add("dark");
    else root.classList.remove("dark");
    localStorage.setItem("theme", t);
  };

  const toggleTheme = () => {
    const next: Theme = theme === "dark" ? "light" : "dark";
    setTheme(next);
    applyTheme(next);
  };

  const check = async () => {
    setConn("checking");
    try {
      await getPlantStatus();
      setConn("online");
    } catch {
      setConn("offline");
    }
    setLastChecked(new Date().toLocaleTimeString());
  };

  useEffect(() => {
    check();
    const interval = setInterval(check, 5000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-50">
      <div className="mx-auto max-w-md px-4 py-6">
        {/* Header */}
        <div className="mb-8 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <Link
              to="/"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-stone-300 bg-white text-stone-600 hover:bg-stone-100 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300 dark:hover:bg-stone-800"
              aria-label="Back to dashboard"
            >
              ←
            </Link>
            <h1 className="text-2xl font-bold tracking-tight">Settings</h1>
          </div>
        </div>

        {/* ESP32 Connection */}
        <section className="mb-6">
          <h2 className="text-sm font-semibold text-stone-500 dark:text-stone-400 uppercase tracking-wider mb-3">Device</h2>
          <div className="rounded-2xl bg-white border border-stone-200 dark:bg-stone-900 dark:border-stone-800 p-5">
            <div className="flex items-center justify-between mb-4">
              <div>
                <p className="text-sm text-stone-400">ESP32</p>
                <p className="text-xs text-stone-500 mt-0.5">http://192.168.1.50/</p>
              </div>
              <ConnPill state={conn} />
            </div>

            <div className="flex items-center justify-between text-xs text-stone-500">
              <span>
                {lastChecked ? `Last checked: ${lastChecked}` : "Checking…"}
              </span>
              <button
                onClick={check}
                className="rounded-lg border border-stone-700 bg-stone-800 px-3 py-1.5 text-stone-200 hover:bg-stone-700"
              >
                Test connection
              </button>
            </div>
          </div>
        </section>

        {/* Appearance */}
        <section className="mb-6">
          <h2 className="text-sm font-semibold text-stone-500 dark:text-stone-400 uppercase tracking-wider mb-3">Appearance</h2>
          <div className="rounded-2xl bg-white border border-stone-200 dark:bg-stone-900 dark:border-stone-800 p-5">
            <div className="mb-4">
              <p className="text-sm font-medium text-stone-900 dark:text-stone-100">Theme</p>
              <p className="text-xs text-stone-500 mt-0.5">
                Currently using {theme === "dark" ? "Dark" : "Light"} mode
              </p>
            </div>

            <div
              role="radiogroup"
              aria-label="Theme"
              className="grid grid-cols-2 gap-2 rounded-xl border border-stone-200 bg-stone-100 p-1 dark:border-stone-800 dark:bg-stone-950"
            >
              <ThemeOption
                label="☀️ Light"
                active={theme === "light"}
                onClick={() => { setTheme("light"); applyTheme("light"); }}
              />
              <ThemeOption
                label="🌙 Dark"
                active={theme === "dark"}
                onClick={() => { setTheme("dark"); applyTheme("dark"); }}
              />
            </div>
          </div>
        </section>
      </div>
    </div>
  );
}

function ConnPill({ state }: { state: ConnState }) {
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium",
        state === "online" && "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
        state === "offline" && "bg-red-500/15 text-red-400 border-red-500/40",
        state === "checking" && "bg-stone-800 text-stone-400 border-stone-700"
      )}
    >
      <span
        className={cn(
          "h-2 w-2 rounded-full",
          state === "online" && "bg-emerald-400 animate-pulse",
          state === "offline" && "bg-red-500",
          state === "checking" && "bg-stone-500 animate-pulse"
        )}
      />
      <span>
        {state === "online" ? "Connected" : state === "offline" ? "Not connected" : "Checking…"}
      </span>
    </div>
  );
}

function ThemeOption({ label, active, onClick }: { label: string; active: boolean; onClick: () => void }) {
  return (
    <button
      type="button"
      onClick={onClick}
      role="radio"
      aria-checked={active}
      className={cn(
        "rounded-lg px-3 py-2 text-sm font-medium transition-colors",
        active
          ? "bg-white text-emerald-600 shadow-sm ring-1 ring-emerald-500/40 dark:bg-stone-800 dark:text-emerald-300 dark:ring-emerald-500/40"
          : "text-stone-500 hover:text-stone-700 dark:text-stone-400 dark:hover:text-stone-200"
      )}
    >
      {label}
    </button>
  );
}
