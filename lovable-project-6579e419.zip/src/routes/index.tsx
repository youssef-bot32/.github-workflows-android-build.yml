import { createFileRoute, Link } from "@tanstack/react-router";
import { useState, useEffect, useRef } from "react";
import { waterPlant, skipWater, getPlantStatus, type PlantStatus } from "@/lib/esp32";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "Smart Plant | Dashboard" },
      { name: "description", content: "Monitor and control your smart plant watering system." },
      { property: "og:title", content: "Smart Plant Dashboard" },
      { property: "og:description", content: "Live ESP32 sensor monitoring for your smart plant." },
    ],
  }),
  component: HomeDashboard,
});

function HomeDashboard() {
  const [data, setData] = useState<PlantStatus | null>(null);
  const [online, setOnline] = useState<boolean>(true);
  const [hasEverConnected, setHasEverConnected] = useState(false);
  const [status, setStatus] = useState<"idle" | "watering" | "skipped">("idle");
  const [toast, setToast] = useState<string | null>(null);
  const mounted = useRef(true);

  useEffect(() => {
    mounted.current = true;
    let cancelled = false;

    const tick = async () => {
      try {
        const res = await getPlantStatus();
        if (cancelled || !mounted.current) return;
        setData(res);
        setOnline(true);
        setHasEverConnected(true);
      } catch {
        if (cancelled || !mounted.current) return;
        setOnline(false);
      }
    };

    tick();
    const interval = setInterval(tick, 5000);
    return () => {
      cancelled = true;
      mounted.current = false;
      clearInterval(interval);
    };
  }, []);

  const showToast = (msg: string) => {
    setToast(msg);
    setTimeout(() => setToast(null), 3000);
  };

  const handleWater = async () => {
    setStatus("watering");
    const result = await waterPlant();
    showToast(result.message);
    setTimeout(() => setStatus("idle"), 2000);
  };

  const handleSkip = async () => {
    setStatus("skipped");
    const result = await skipWater();
    showToast(result.message);
    setTimeout(() => setStatus("idle"), 2000);
  };

  const temp = data ? `${data.temp} °C` : "—";
  const hum = data ? `${data.hum} %` : "—";
  const last = data?.last ?? "—";
  const next = data?.next ?? "—";
  const state = data?.state ?? "—";

  return (
    <div className="min-h-screen bg-stone-50 text-stone-900 dark:bg-stone-950 dark:text-stone-50">
      {toast && (
        <div className="fixed top-4 right-4 z-50 animate-in fade-in slide-in-from-top-2 duration-300">
          <div className="rounded-xl bg-stone-800 border border-stone-700 px-4 py-3 shadow-lg">
            <p className="text-sm font-medium">{toast}</p>
          </div>
        </div>
      )}

      <div className="mx-auto max-w-md px-4 py-6">
        {/* Header */}
        <div className="mb-8 flex items-start justify-between">
          <div>
            <h1 className="text-2xl font-bold tracking-tight">Smart Plant</h1>
          </div>
          <div className="flex items-center gap-2">
            <ConnectionIndicator online={online} hasEverConnected={hasEverConnected} />
            <Link
              to="/settings"
              className="flex h-9 w-9 items-center justify-center rounded-full border border-stone-300 bg-white text-stone-600 hover:bg-stone-100 dark:border-stone-800 dark:bg-stone-900 dark:text-stone-300 dark:hover:bg-stone-800"
              aria-label="Settings"
            >
              ⚙️
            </Link>
          </div>
        </div>

        {/* Live sensor cards */}
        <div className="grid grid-cols-2 gap-3 mb-6">
          <SensorCard title="Temperature" value={temp} icon="🌡️" accent="text-amber-300" />
          <SensorCard title="Humidity" value={hum} icon="💧" accent="text-sky-300" />
          <SensorCard title="Last Watering" value={last} icon="🕒" accent="text-stone-100" />
          <SensorCard title="Next Watering" value={next} icon="⏳" accent="text-emerald-300" />
        </div>

        <div className="mb-6">
          <SensorCard title="Status" value={state} icon="🌱" accent="text-emerald-400" wide />
        </div>

        {/* Quick Actions */}
        <div className="mb-6">
          <h2 className="text-sm font-semibold text-stone-500 dark:text-stone-400 uppercase tracking-wider mb-3">Quick Actions</h2>
          <div className="flex gap-3">
            <button
              onClick={handleWater}
              disabled={status !== "idle"}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 rounded-2xl py-4 font-semibold text-sm transition-all duration-200",
                status === "watering"
                  ? "bg-emerald-700 text-white animate-pulse"
                  : "bg-emerald-600 hover:bg-emerald-500 text-white active:scale-[0.98]"
              )}
            >
              <span>{status === "watering" ? "💦 Watering..." : "💧 Water Now"}</span>
            </button>
            <button
              onClick={handleSkip}
              disabled={status !== "idle"}
              className={cn(
                "flex-1 flex items-center justify-center gap-2 rounded-2xl py-4 font-semibold text-sm transition-all duration-200 border",
                status === "skipped"
                  ? "bg-stone-700 border-stone-600 text-stone-300"
                  : "bg-stone-900 border-stone-700 text-stone-300 hover:bg-stone-800 hover:border-stone-600 active:scale-[0.98]"
              )}
            >
              <span>{status === "skipped" ? "⏭️ Skipped" : "⏭️ Skip Water"}</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function ConnectionIndicator({ online, hasEverConnected }: { online: boolean; hasEverConnected: boolean }) {
  const isOffline = !online && hasEverConnected;
  const isConnecting = !online && !hasEverConnected;
  return (
    <div
      className={cn(
        "flex items-center gap-2 rounded-full border px-3 py-1.5 text-xs font-medium",
        online && "bg-emerald-500/15 text-emerald-300 border-emerald-500/30",
        isOffline && "bg-red-500/15 text-red-400 border-red-500/40",
        isConnecting && "bg-stone-800 text-stone-400 border-stone-700"
      )}
    >
      <span
        className={cn(
          "h-2 w-2 rounded-full",
          online && "bg-emerald-400 animate-pulse",
          isOffline && "bg-red-500",
          isConnecting && "bg-stone-500 animate-pulse"
        )}
      />
      <span>{online ? "Online" : isOffline ? "Device Offline" : "Connecting…"}</span>
    </div>
  );
}

function SensorCard({
  title,
  value,
  icon,
  accent,
  wide,
}: {
  title: string;
  value: string;
  icon: string;
  accent?: string;
  wide?: boolean;
}) {
  return (
    <div
      className={cn(
        "rounded-2xl bg-white border border-stone-200 dark:bg-stone-900 dark:border-stone-800 p-4",
        wide && "flex items-center justify-between"
      )}
    >
      <div className="flex items-center gap-2 mb-2">
        <span className="text-base">{icon}</span>
        <span className="text-xs text-stone-500 uppercase tracking-wider">{title}</span>
      </div>
      <p className={cn("text-2xl font-bold tabular-nums", accent ?? "text-stone-100")}>{value}</p>
    </div>
  );
}
