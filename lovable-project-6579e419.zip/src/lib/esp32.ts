export async function waterPlant(): Promise<{ success: boolean; message: string }> {
  try {
    const res = await fetch("http://192.168.1.50/water", {
      method: "GET",
      mode: "no-cors",
    });
    return { success: true, message: "Watering started!" };
  } catch {
    return { success: false, message: "Failed to reach ESP32. Check your connection." };
  }
}

export async function skipWater(): Promise<{ success: boolean; message: string }> {
  try {
    const res = await fetch("http://192.168.1.50/skip", {
      method: "GET",
      mode: "no-cors",
    });
    return { success: true, message: "Watering skipped." };
  } catch {
    return { success: false, message: "Failed to reach ESP32. Check your connection." };
  }
}

export interface PlantStatus {
  temp: number;
  hum: number;
  last: string;
  next: string;
  state: string;
}

export async function getPlantStatus(): Promise<PlantStatus> {
  const controller = new AbortController();
  const timeout = setTimeout(() => controller.abort(), 4000);
  try {
    const res = await fetch("http://192.168.1.50/", {
      method: "GET",
      signal: controller.signal,
    });
    if (!res.ok) throw new Error(`HTTP ${res.status}`);
    return (await res.json()) as PlantStatus;
  } finally {
    clearTimeout(timeout);
  }
}
